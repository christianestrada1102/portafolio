module mx.edu.utch.ejem14database {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.sql;
    requires mysql.connector.j;

    opens modelo to javafx.fxml,java.base;
    exports modelo;

    opens mx.edu.utch.ejem14database to javafx.fxml;
    exports mx.edu.utch.ejem14database;
}