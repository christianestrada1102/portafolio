package modelo;

import java.util.ArrayList;

public interface Database {
    void connect();
    void disconnect();

    void create (Estudiante estudiante);
    void read (Estudiante estudiante);
    void update (Estudiante estudiante);
    void delete (Estudiante estudiante);
    ArrayList<Estudiante> getAlumni();
    String messanger(String msg);
}
