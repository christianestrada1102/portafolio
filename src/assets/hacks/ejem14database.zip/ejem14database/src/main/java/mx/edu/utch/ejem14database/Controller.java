package mx.edu.utch.ejem14database;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import modelo.Database;
import modelo.Estudiante;
import modelo.JMysql;

public class Controller implements EventHandler<ActionEvent> {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button btnActualizar;

    @FXML
    private Button btnEliminar;

    @FXML
    private Button btnGuardar;

    @FXML
    private Button btnPrevio;

    @FXML
    private Button btnSiguiente;

    @FXML
    private TableColumn<Estudiante, String > colApellido;

    @FXML
    private TableColumn<Estudiante, String> colMatricula;

    @FXML
    private TableColumn<Estudiante, String> colNombre;

    @FXML
    private TableColumn<Estudiante, String> colTelefono;

    @FXML
    private TableView<Estudiante> tblEstudiantes;

    @FXML
    private TextField txtApellido;

    @FXML
    private TextField txtMatricula;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtTelefono;

    private Database db;


    @FXML
    void initialize() {
        db = JMysql.getInstance();
        db.connect();
        db.read(null);
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colApellido.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        colMatricula.setCellValueFactory(new PropertyValueFactory<>("matricula"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<>("telefono"));
        filler();
//        ArrayList<Estudiante> alumni = db.getAlumni();
//        for (Estudiante es: alumni){
//            IO.println("Estudiante: " + es.getNombre());
//        }
//        db.disconnect();

    }

    private void filler() {
        tblEstudiantes.getItems().clear();
        if (db.getAlumni().size() > 0){
            tblEstudiantes.getItems().addAll(db.getAlumni());
            tblEstudiantes.refresh();
        }
    }

    @Override
    public void handle(ActionEvent event) {
        Object obj =event.getSource();
        if (obj instanceof Button){
            Button btn = (Button) obj;
            if (btn == btnGuardar){
                adder();
            }
        }
    }

    private void adder() {
        if (txtNombre.getText().isEmpty() || txtApellido.getText().isEmpty() || txtMatricula.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "campos vacios");
            alert.showAndWait();

        } else {
            Estudiante noob = new Estudiante();
            noob.setNombre(txtNombre.getText());
            noob.setApellido(txtApellido.getText());
            noob.setMatricula(txtMatricula.getText());
            noob.setTelefono(txtTelefono.getText());
            noob.setFecha(LocalDate.now());
            noob.setCarrera("TIC");

            tblEstudiantes.getItems().add(noob);
            tblEstudiantes.refresh();
            db.create(noob);
        }
    }

    public void seleccionado(MouseEvent mouseEvent) {
        if (tblEstudiantes.getSelectionModel().getSelectedItem() != null){
            fillData();
        }
    }
    
    private void fillData(){
        Estudiante estudiante = tblEstudiantes.getSelectionModel().getSelectedItem();
        txtNombre.setText(estudiante.getNombre());
        txtApellido.setText(estudiante.getApellido());
        txtMatricula.setText(estudiante.getMatricula());
        txtTelefono.setText(estudiante.getTelefono());
    }
}
