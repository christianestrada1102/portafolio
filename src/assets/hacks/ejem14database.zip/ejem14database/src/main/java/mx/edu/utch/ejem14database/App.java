package mx.edu.utch.ejem14database;

import javafx.application.Application;

public class App {
    public static void main(String[] args) {
        Application.launch(Crud.class, args);
    }
}
