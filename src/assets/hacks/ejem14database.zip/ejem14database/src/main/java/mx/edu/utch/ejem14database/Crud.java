package mx.edu.utch.ejem14database;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Crud extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Crud.class.getResource("crud.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 410, 600);
        stage.setTitle("Im Crud!");
        stage.setScene(scene);
        stage.show();
    }
}
