package modelo;

public interface Sql {
    String selecto= "SELECT * FROM alumnos ";
    String selecto_1 = "SELECT * FROM alumnos where id=?";
    String delecto = "Delate FROM alumnos where id=?";
    String updato = "update alumnos set nombre =?,apellido=?,carrera=?,matricula=?,telefono=? fecha=? where id=?";
    String insert = "insert into alumnos(nombre, apellido,telefono, matricula, carrera, fecha)" +
            "values(?,?,?,?,?,?)";


}
