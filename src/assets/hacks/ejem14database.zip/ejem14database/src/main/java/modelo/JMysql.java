package modelo;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class JMysql implements Database {
    private String message;
    private Connection connection;
    private int id;
    private ArrayList<Estudiante>  alumni;

    private static final JMysql instance = new JMysql();


    public static JMysql getInstance(){
        return instance;
    }
    private JMysql() {
        this.id = -1;
        this.alumni = new ArrayList<>();

    }

    public int getId() {
        return id;
    }

    @Override
    public void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            connection = DriverManager.getConnection("jdbc:mysql://localhost:8989/student", "dev","dev");
            boolean valida = connection.isValid(500);
            if (!valida){
                IO.println("no se pudo conectar al servidor");
            } else {
                IO.println("conexion establecida");
            }
        }catch (ClassNotFoundException e){
            IO.println(e.getMessage());
        } catch (SQLException e) {
            IO.println(e.getMessage());
        }
    }

    @Override
    public void disconnect() {
        try {
            if (connection!= null && !connection.isClosed() ){
                connection.close();
                IO.println("Desconectado");
            }
        } catch (SQLException e) {
            IO.println(e.getMessage());
        }

    }

    @Override
    public void create(Estudiante estudiante) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(Sql.insert,Statement.RETURN_GENERATED_KEYS);
            statement.setString(1,estudiante.getNombre());
            statement.setString(2,estudiante.getApellido());
            statement.setString(3,estudiante.getMatricula());
            statement.setString(4,estudiante.getCarrera());
            statement.setString(5,estudiante.getTelefono());
            statement.setDate(6,java.sql.Date.valueOf(estudiante.getFecha()));

            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();
            if (rs.next()){
                this.id = rs.getInt(1);
            }
        } catch (SQLException e) {
            IO.println(e.getMessage());
        }
    }

    @Override
    public void read(Estudiante estudiante) {
        PreparedStatement statement = null;
        try {
            if (estudiante == null){
                statement = connection.prepareStatement(Sql.selecto);
            } else {
                statement = connection.prepareStatement(Sql.selecto_1);
                statement.setInt(1, estudiante.getId());
            }
            ResultSet datos = statement.executeQuery();
            while (datos.next()){
                this.id=datos.getInt("id");
                String nombre = datos.getString("nombre");
                String apellido = datos.getString("apellido");
                String matricula = datos.getString("matricula");
                String carrera = datos.getString("carrera");
                String telefono = datos.getString("telefono");
                LocalDate fecha = LocalDate.parse(datos.getDate("fecha_ingreso").toString());

                Estudiante est = new Estudiante();
                est.setNombre(nombre);
                est.setMatricula(matricula);
                est.setId(this.id);
                est.setApellido(apellido);
                est.setCarrera(carrera);
                est.setTelefono(telefono);
                est.setFecha(fecha);
                alumni.add(est);
            }
        } catch (SQLException e) {
            IO.println(e.getMessage());
        }
    }

    @Override
    public void update(Estudiante estudiante) {

    }

    @Override
    public void delete(Estudiante estudiante) {

    }

    @Override
    public ArrayList<Estudiante> getAlumni() {
        return alumni;
    }

    @Override
    public String messanger(String msg) {
        return "";
    }
}
